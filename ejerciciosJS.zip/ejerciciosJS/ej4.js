function potencia(base = 3, exponente = 3) {
  return base ** exponente;
}
console.log("ejercicio 4 :")
console.log(potencia());
console.log(potencia(1, 2));
console.log(potencia(2, 3));
