let edad=18;
let esMayor=(edad>=18)?"Mayor de edad":"Menor de edad";
console.log("Ejercicio 8:");
console.log(esMayor);