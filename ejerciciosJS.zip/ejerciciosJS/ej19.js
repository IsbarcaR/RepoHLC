console.log("Ejercicio 19");
let nombre = "Juan";
edad = 30;
let ciudad = "Madrid";

// Uso de template literals
let mensaje = `Hola, mi nombre es ${nombre}, tengo ${edad} años y vivo en ${ciudad}.`;

// Mostrar el mensaje en la consola
console.log(mensaje);

// Mostrar el mensaje en un alert
alert(mensaje);
