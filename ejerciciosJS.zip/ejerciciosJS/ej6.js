const funcionArrow= (texto) => {
    console.log(texto);
}
console.log("Ejercicio 6");
funcionArrow("Hola, soy una función arrow");